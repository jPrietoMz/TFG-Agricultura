package com.tfg.agricultura.agricultura_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgriculturaBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
